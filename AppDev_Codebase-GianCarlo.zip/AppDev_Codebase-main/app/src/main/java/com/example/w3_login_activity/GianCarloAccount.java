package com.example.w3_login_activity;

/**
 * Separate demo account details for Gian Carlo P. Cahila.
 * For classroom testing only. Do not store real passwords in source code.
 */
public final class GianCarloAccount {
    public static final String FULL_NAME = "GIan Carlo P. Cahila";
    public static final String EMAIL = "cahilagp@students.national-u.edu.ph";
    public static final String PASSWORD = "password123";

    private GianCarloAccount() { }
}
